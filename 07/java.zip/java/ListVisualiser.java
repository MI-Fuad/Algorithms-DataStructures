public class ListVisualiser {
    public ListVisualiser(SLList l){
        
        
    }
    public void visualise() {
        
    
    }
}
