class SLList {
    Object firstList;
    SLList restOfList;
    public SLList(Object f, SLList r) {
        firstList = f;
        restOfList = r;

    }
    public static final SLList NIL = new SLList(0, null);

    public Object first() {
        return firstList;
    }
    public SLList rest() {
        return restOfList;
    }
    public void setFirst(Object f) {
        firstList = f;
    }
    public void setRest(SLList r) {
        restOfList = r;
    }

    public Object nth(int i) {
        int counter = 0;
        if (i == 0){
            return this.first();
        }else{
            counter++;
            return this.rest().nth(i-1);
        }
    }
    
    public SLList nthRest(int i){
        int counter = 0;
        SLList ongoing = this;
        boolean notFound = true;
        while(notFound){
            if(counter == i){
                notFound = false;
                return ongoing;
            }
            counter++;
            ongoing = ongoing.rest();
        }return ongoing;
    //return [0,1,2,n,3,4,5,6] nthRest(n) = [3,4,5,6]
    }
    // no such thing as `unsigned' in Java
    public int length() {
        if(restOfList == null){
            return 0;
        }else{
            return 1 + restOfList.length();
        }
    }

    

   





  
}
